<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<!-- CSS
================================================== -->
<link href="css/gsi-step-indicator.min.css" rel="stylesheet" />

<link rel="stylesheet" href="css/tsf-step-form-wizard.min.css">
<link href="css/demo.min.css" rel="stylesheet" />
<link href="css/parsley.min.css" rel="stylesheet" />
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/main.css" id="colors">
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">

<link rel="stylesheet" href="css/costume.css">

